package daten;

import java.util.ArrayList;

/**
 * Klasse Gebiete ist eine ArrayListe vom Typ Gebiet
 * @author Sarah, Jessica
 *
 */
public class Gebiete extends ArrayList<Gebiet>
{
	private static final long serialVersionUID = 1L;

}
