package daten;

import java.util.ArrayList;
/**
 * 
 * @author Sarah, Jessica
 * Die Klasse Schulen ist eine ArrayList vom Typ Schule
 *
 */
public class Schulen extends ArrayList<Schule>
{
	private static final long serialVersionUID = 1L;
	
}
